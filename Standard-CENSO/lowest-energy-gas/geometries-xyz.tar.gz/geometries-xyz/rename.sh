for file in *-h2o*; do
    mv -- "$file" "${file//-h2o/-gas}"
done
